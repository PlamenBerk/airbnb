import { ClientDashboardPage } from "@/components/client-dashboard-content"

export default function Dashboard() {
  return <ClientDashboardPage />
}

