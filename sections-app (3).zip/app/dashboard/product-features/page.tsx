import { ClientArchitecturePage } from "@/components/client-architecture-content"

export default function Architecture() {
  return <ClientArchitecturePage />
}

