import { ClientGuidesPage } from "@/components/client-guides-content"

export default function CityGuides() {
  return <ClientGuidesPage />
}

