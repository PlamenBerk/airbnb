import { ClientResourcesPage } from "@/components/client-resources-content"

export default function UrbanResources() {
  return <ClientResourcesPage />
}

